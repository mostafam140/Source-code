function [c, ceq] = SQP_nonlcon(x)

global  Inde  w  W_T  func  func_sqp  funcname  obj_num  w_ind  F_e

% if funcname == 'dtlz1'
% % obj_num
% % x

for ii = 1 : 3
    
    x(ii) = round(x(ii)) ;
            
end

[f_val,g,x] = func_sqp(obj_num(1),real(x)) ;

%     elseif funcname == 'dtlz2'
        
%         [f_val,g,x] = dtlz2(obj_num(1),real(x)) ;
        
% end  

% anda = norm(W_T(p1,:)) ;

% d1 = f_val*w(Inde,:)' ;

% d2 = sqrt(abs((norm(f_val))^2-d1^2)) ;

% cos_th = (f_val*w(Inde,:)') / (norm(f_val)*norm(w(Inde,:))) ;

% theta = acosd(cos_th) ;

[Cons_LP, C_AD] = nlcon_mo(x) ;

c = [ abs(f_val(1,1)-F_e(w_ind,1))-0.001
      Cons_LP
      C_AD+(-1e-6) ] ;    % in second level, due to computational errors (from rounding or approximations) some elemnts of A or D bacome -1e-12  ; F_e(w_ind,1) - 0.01 ;

% c = d2 - 0.1 ;

ceq  = [] ;


 
%     g = 100*(K + sum) ;  % 5 is K parameter and set to 5 based on NSWU A Decomposition Based ..., Asafuddoula, 2014  1 + 9*sum(popVar(i,2:numVar))/(numVar-1);
%     
%     f1 = 0.5*x(1)*x(2)*(1+g) ;
% 
%     f2 = 0.5*x(1)*(1-x(2))*(1+g) ;
% 
%     f3 = 0.5*(1-x(1))*(1+g) ;
%         
% %     for j = 1 : size(W,1)
%         
%         d1 = f1*w(ghj,1) + f2*w(ghj,2) + f3*w(ghj,3) ;
%                 
%         d2 = sqrt((f1^2 + f2^2 + f3^2) - d1^2) ;
%         
%         if ((f1^2 + f2^2 + f3^2) - d1^2 < 0)
%                         
%             d2 = 0 ;            
%             
%         end
%         
%         if ((f1^2 + f2^2 + f3^2) - d1^2 < -0.05)
%             
%             (f1^2 + f2^2 + f3^2) - d1^2
%             d2
%             d2 = 0 ;
%             input('line 40  DTLZ_1_SQP_nonlcon(x) ')
%             
%         end                        
        
% %     end
    
end
