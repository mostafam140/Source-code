function [pf,g,x] = Wei_Buc_scnd(obj_num,popVar)   % i_g

global  U  th  rho  a_r  b_s  sigma_2  sigma_3  sigma_4  sigma_5  sigma_6  E1  E2  E3  G12  G13  G23  NU21  NU23  NU31  ...
        Q  N_x  N_y  N_xy  func_count

func_count = func_count + 1 ;

i_g = 1 ;

for ii = 1 : 3
    
    popVar(i_g,ii) = round(popVar(ii)) ;
            
end

g = 1 ;

% [U , Q , th , ~ , a_r , b_s , N_x , N_y] = inputs() ;

x = popVar(i_g,:) ;

NN(1) = popVar(i_g,1) ;
NN(2) = popVar(i_g,2) ;
NN(3) = popVar(i_g,3) ;

xi_1_A = (NN(1)-NN(3))/(NN(1)+NN(3)+2*NN(2)) ;
xi_2_A = 0 ;
xi_3_A = (NN(1)+NN(3)-2*NN(2))/(NN(1)+NN(3)+2*NN(2)) ;
xi_4_A = 0 ;

%% First Objective funstion

pf(1) = a_r*rho*b_s*2*(NN(1) + 2*NN(2) + NN(3))*th ;  % 1000 is applied to convert kg to gr

%% Second Objective funstion
% tic
[ Stack_Seq ] = sec_level(i_g, popVar) ; % [90  90  45 -45  45 -45  90  90  45 -45  90  90  45 -45  45 -45  45 -45  45 -45  45 -45  45 -45 ...
%     -45 45  -45 45  -45 45  -45 45  -45 45  -45 45  90  90  -45 45 90  90  -45 45  -45 45  90  90] ; % l;
% toc
input('Wei_Buc.m, line 40')

all_ang = Stack_Seq  ;
k = {} ;

N = length(all_ang) ;
h = zeros(N+1,1) ;
h(N+1) = N*th/2 ;   % (popVar(i,1)+popVar(i,2)+popVar(i,3)+popVar(i,4))/2 ; %  2*(0.25 + popVar(i_g,1)*(0.125) + popVar(i_g,2)*(0.125) + 0.25 )/(1000*2) ; % 
lstf = zeros(3*N,3) ;

for k = 1 : N
    
        %%Compliance Matrix elements
        S = [1/E1     -NU21/E1    -NU31/E1    0         0       0;
            -NU21/E1   1/E2       -NU23/E2    0         0       0;
            -NU31/E1   -NU23/E2     1/E3      0         0       0;
            0           0           0       1/G23     0       0;
            0           0           0        0       1/G13    0;
            0            0          0        0       0       1/G12];

        %%Stiffness Matrix elements
        C = inv(S);
        
        %Reduced Stiffness
        Q_ = zeros(3,3);
        Q_(1,1) = C(1,1) - (C(1,3))^2 / C(3,3);
        Q_(2,2) = C(2,2) - (C(2,3))^2 / C(3,3);
        Q_(1,2) = C(1,2) - C(1,3)*C(2,3) / C(3,3);
        Q_(2,1) = Q_(1,2);
        Q_(3,3) = C(6,6);
        Q_code = Q_ ;
        
%Transformatioin Matrix        

        m = cosd(all_ang(k));
        n = sind(all_ang(k));

        T = zeros(3,3);
        T(1,1) = m^2;
        T(1,2) = n^2;
        T(1,3) = 2*m*n;
        T(2,1) = n^2;
        T(2,2) = m^2;
        T(2,3) = -2*m*n;
        T(3,1) = -m*n;
        T(3,2) = m*n;
        T(3,3) = m^2-n^2;
     
        %Transformed Stiffness
        q = zeros(3,3);
        q([1:2],[1:2]) = Q_([1:2],[1:2]);
        q(3,3) = 2*Q_(3,3);

        q = inv(T)*q*T;
        for i = 1:3
            q(i,3) = q(i,3)/2;
        end

        lstf([3*k-2:3*k],[1:3]) = q([1:3],[1:3]);   % Mos% :Off axis stiffnesses

        h(k) = (k - N/2 - 1)*th ;
end

% h(1) = (-0.25-0.125*popVar(i_g,1)-0.125*popVar(i_g,2)-0.25 )/1000 ;
% h(2) = (-0.125*popVar(i_g,1)-0.125*popVar(i_g,2)-0.25 )/1000 ;
% h(3) = (-0.125*popVar(i_g,2)-0.25 )/1000 ;
% h(4) = (-0.25 )/1000 ;
% h(5) = 0 ;
% h(6) = (0.25 )/1000 ;
% h(7) = (0.125*popVar(i_g,2)+0.25 )/1000 ;
% h(8) = (0.125*popVar(i_g,1)+0.125*popVar(i_g,2)+0.25 )/1000 ;

% To Calculate A B and D Matrices for Uniform Laminate

A = zeros(3,3) ;
B = zeros(3,3) ;
D = zeros(3,3) ;

    for i = 1:3
        for j = 1:3
            q([1:3],[1:3]) = lstf([1:3],[1:3]);
            A(i,j) = q(i,j) * (h(2) - h(1));
            B(i,j) = 1/2*(q(i,j) * (h(2)^2 - h(1)^2));
            D(i,j) = (1/3)*(q(i,j) * (h(2)^3 - h(1)^3));

            for k = 2 : N
            q([1:3],[1:3]) = lstf( [3*k-2:3*k] , [1:3] );
            A(i,j) = q(i,j) * (h(k+1) - h(k)) + A(i,j);
            B(i,j) = 1/2*(q(i,j) * (h(k+1)^2 - h(k)^2)) + B(i,j);
            D(i,j) = (1/3)*(q(i,j) * (h(k+1)^3 - h(k)^3)) + D(i,j);
            end
        end
    end    
    
    A = A/1000 ;
    D = D/1000 ;

    %% A and D using lamination parameters
% xi_1_D = popVar(i_g,4) ;        % Commented on 97-6-11
% xi_2_D = popVar(i_g,5) ;
% xi_3_D = popVar(i_g,6) ;
% xi_4_D = 0 ;
% 
% DD = [1  xi_1_D    xi_2_D  0  0
%               1  -xi_1_D   xi_2_D  0  0
%               0  0        -xi_2_D  1  0
%               0  0        -xi_2_D  0  1
%               0  xi_3_D/2  0       0  0
%               0  xi_3_D/2  0       0  0] ;
%            
%             D_temp = zeros(6,1);
%             
%             D_temp = DD*U ;
% 
%             D = zeros(3,3);
% 
%             H = 2*( NN(1) + 2*NN(2) + NN(3) )*th ;   % 2 is added to consider the symmetric Stack            
%             
%             D = ((H^3)/12)*[D_temp(1)  D_temp(3)   D_temp(5)          %  H: plate thickness
%                             D_temp(3)  D_temp(2)   D_temp(6)
%                             D_temp(5)  D_temp(6)   D_temp(4)] ;
%             
%             AA = [1  xi_1_A     xi_3_A   0  0
%                   1  -xi_1_A    xi_3_A   0  0
%                   0  0         -xi_3_A   1  0
%                   0  0         -xi_3_A   0  1
%                   0  xi_2_A/2   xi_4_A   0  0
%                   0  xi_2_A/2  -xi_4_A   0  0] ;
% 
%             A_temp = zeros(6,1);
%             A_temp = AA*U ;
% 
%             A = zeros(3,3);
% 
%             A = (H)*[A_temp(1)  A_temp(3)   A_temp(5)          %  H: plate thickness
%                  A_temp(3)  A_temp(2)   A_temp(6)
%                  A_temp(5)  A_temp(6)   A_temp(4)] ;
% 
%             A = A/1000 ;
%             D = D/1000 ;
            
            
            Eq29 = -min(min(A)) ;
            Eq30 = -min(min(D)) ;                        
            
            C_AD = max(Eq29 , Eq30) ;
    
            Cons = -1 ; %    C_AD = -1 ;
            
            if ( Cons <= 0 ) && ( C_AD <= (1e-6) )    % in the second level, due to computational errors (from rounding or approximations) some elemnts of A or D bacome -1e-12  ;
                
%                 Num_lay = [ NN(1), NN(2), NN(3) ] ;
                
%                 fprintf('    h1 = %5.3f   h2 = %5.3f  (mm) \n\n' , popVar(i_g,1) , popVar(i_g,2) )
                
%                 fprintf('    f (=h1+h2) = %5.2f  (mm) \n\n' , sum(popVar(i_g,:)) )

%                 [sigma_1, sigma_2, sigma_6] = structure_anal(A,B,D,h) ;

% tic
% [ Stack_Seq ] = sec_level(i_g, popVar) ;
% toc
% input('191')

% %                 [sigma_1, sigma_2, sigma_3, sigma_4, sigma_5, sigma_6, lambda] =  Run_ANSYS(Stack_Seq) ;  % Here sigma is in [Pa]
%                 input('194')
                
% %                 fprintf('    Calculating the reliability ... \n\n' )
%                 tic
% %                 Reli_st = MC() ;
%                 toc
% %                 PF_f2 = 100 - Reli_st ;      % MC: Mont carlo function file which calculates the reliability                                
                
%                 fprintf('    Reliability =  %7.4f  \n\n' , Reli_st )

                    % Axial buckling factor
                    for mm = 1 : 15

                        for nn = 1 : 15
                            
                            lambda1(mm,nn) = ( D(1,1)*((mm/a_r)^4) + 2*(D(1,2)+2*D(3,3))*((mm/a_r)^2)*((nn/b_s)^2)+D(2,2)*((nn/b_s)^4) ) / ( ((mm/a_r)^2)*N_x +((nn/b_s)^2)*N_y ) ;
                            lambda1(mm,nn) = lambda1(mm,nn)*(pi^2) ;
                            
                        end
                    end
                  
                    pf(2) = 2-min(min(abs(lambda1))) ;
            else
%                 Cons
%                 C_AD                
                
                fprintf('constraints are violated, Wei_Buc, line 234')
%                 input('constraints are violated, Wei_Buc, line 234')
                
                pf(2) = 2 ;    % 90 ;
            end
            
            
%             for i_pl = 1 : size(F_e2,1)
    
                p4 = plot(1000*pf(1), 2-pf(2),'o','LineWidth',1,...
                    'MarkerEdgeColor','k',...
                    'MarkerFaceColor','b',...
                    'MarkerSize',6) ;

                    if (2-pf(2)) < 1
                        
                        plot(1000*pf(1), 2-pf(2),'o','LineWidth',1,...
                            'MarkerEdgeColor','k',...
                            'MarkerFaceColor','r',...
                            'MarkerSize',6) ;

                    end
        
                        pause(0.1)
                hold on
%             end

            popVar
            Stack_Seq
            
            fprintf('    N_0 = %5.1f    N_45 =  %5.1f    N_90 =  %5.1f    N_total =  %5.1f  \n' , popVar(i_g,1),  popVar(i_g,2),  popVar(i_g,3) , 2*(NN(1) + 2*NN(2) + NN(3)) )
            
            fprintf('    Weight(gr) = %6.1f    lambda  =  %6.2f    \n' , 1000*pf(1) , 2-pf(2) )
            
%             if (size(Stack_Seq,2) ~= 2*(NN(1) + 2*NN(2) + NN(3)))
%                 Stack_Seq
%                 input('line 265')
%             end
            
            fprintf('    -------------------------------------- \n')  
    
            
            





