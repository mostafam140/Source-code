function [x_e2, F_e2] = SQP_Run(w_dense, F_e, x_e)
% First please run PSO_test to set initial data, Cancel it, and then run
% this m.file
global Inde  Ref_point  func  obj_num  func_count  F_e  w_te  w  s1  w_ind  func_count_PSO  func_count_SQP  lb  ub

w = w_dense ;

func_count_PSO = func_count ;  
    
if min(F_e) < 0
    input('Error: F_e has a nefative member, IGD_SQP.m_line: 13')
end

si_Fe = size(F_e,1) ;

size(F_e)
size(x_e)

for w_ind = 1 : size(F_e,1)

%     for i_4 = 1 : size(F_e,1)
%         
%         cos_th = (F_e(i_4,:)*w(w_ind,:)') / (norm(F_e(i_4,:))*norm(w(w_ind,:))) ;
%         
%         theta(i_4) = acosd(cos_th) ;
%             
% %         d1_c(i_4) = F_e(i_4,:)*w(w_ind,:)' ;
% %         d2_c(i_4) = sqrt(norm(F_e(i_4,:))^2-d1_c(i_4)^2) ;
%         
%     end        
    
%     [Y_m, Ind] = sort(theta) ;              
    
    x0 = x_e(w_ind,:) ; %        x_e(Ind(1),:) ;  %  (w_ind,:) 
    
    d1_c = F_e(w_ind,:)*w(w_ind,:)' ;
    
    Inde = w_ind ;
    
    Ref_point(Inde,:) = 0.9*d1_c*w(w_ind,:) ;
    
    
    [f_val,g,x] = func(obj_num,x0) ;
    
    bfval(w_ind,:) = f_val ;
    
    for i_j = 1 : min(50,size(F_e,1))
        
%         x0 = x_e(Ind(i_j),:) ;        
        
%         input('SQP run, line 47')
	
%         lb_sqp = x0 - 0.5 ;   %  zeros(1,size(x0,2)) ; % [0 0 0 0 0 0 0] ; %  
%         ub_sqp = x0 + 0.5 ;   %  ones(1,size(x0,2)) ; %  [1 1 1 1 1 1 1] ; % 
        
        
        for ii = 1 : 3
            
            lb_sqp(ii) = max(lb(ii),x0(ii)-2) ;
            
%             if lb_sqp(ii)<lb(ii) 
%                 lb_sqp(ii) = lb(ii) ;
%             end

            ub_sqp(ii) = min(ub(ii),x0(ii)+2) ;
            
%             if ub_sqp(ii) > ub(ii)
%                 ub_sqp(ii) = ub(ii) ;
%             end
            
        end
    

        for ii = 4 : 6
            
            lb_sqp(ii) = max(lb(ii),x0(ii)-0.5) ;
            
%                 if lb_sqp(ii)<-1 
%                     lb_sqp(ii) = -1 ;
%                 end

            ub_sqp(ii) = min(ub(ii),x0(ii)+0.5) ;

%                 if ub_sqp(ii) > 1
%                     ub_sqp(ii) = 1 ;
%                 end

        end
        

	
        
%         for ii = 1 : size(x0,2)
%             if lb(ii)<0 
%                 lb(ii) = 0 ;
%             end
%             
%             if ub(ii) > 1
%                 ub(ii) = 1 ;
%             end
%             
%         end
        
        options = optimset('LargeScale','off' , 'Algorithm' , 'sqp' , 'MaxIter',1000,'MaxFunEvals',3000,...
            'TolFun',1e-8,'TolX',1e-7,'TolCon',1e-3,'Diagnostics','off','Display','off') ;
        
        x0
        input('SQP_Run.m, line 105')
        [x_x ,FVAL,EXITFLAG,OUTPU ] = fmincon(@SQP_obj,x0,[],[],[],[],lb_sqp,ub_sqp,@SQP_nonlcon, options) 
%         FVAL
%         x_x
%       DTLZ_SQP_obj       @DTLZ_SQP_nonlcon
        [f_val,g,x] = func(obj_num,real(x_x)) ;
        
%         if min(f_val) < -0.05
%             x_x = x0 
%             [f_val,g,x] = func(obj_num,real(x0)) 
%             input('min(f_val) < 0.05')
%         end
        
        bfval(w_ind,:) = f_val ;
            
        x_e2(w_ind,:) = x_x ;
        F_e2(w_ind,:) = f_val ;
        
        break
        
    end
    
    sum_er1 = 0 ;
    for re_cn = 1 : obj_num
        sum_er1 = sum_er1 + (bfval(w_ind,re_cn)-w(w_ind,re_cn))^2 ;
    end                    
    error_After1(w_ind) = sqrt( sum_er1 ) ;
    
%     fprintf(' interior-point:  error_After1(%4.0f ) = %14.10f \n' , w_ind , error_After1(w_ind) )
	
    I_J(w_ind) = i_j ;
%     fprintf('  I_J = %4.0f \n' , I_J(w_ind) )
                 
% 	fprintf('  ------------------   END   ------------------   w_ind = %5.1f  \n' , w_ind )
        
    
%     figure(5)
%     plot(1000*(bfval(w_ind,1)+1), 2-bfval(w_ind,2), 'k*')
%     
%     grid on
%     hold on
%     
% %     plot(Ref_point(w_ind,1), Ref_point(w_ind,2), 'ro')
%     
%     set(gca,'FontName','Times New Roman','FontSize',13) ;     % set font size and type for axis numbers
% 
% %     xlim([1300  2000])
% %     ylim([0.5  3])
% 
%     xlabel('f_1','FontName','Times New Roman','FontSize',13,'FontAngle','italic')
%     ylabel('f_2','FontName','Times New Roman','FontSize',13,'FontAngle','italic')
%     
%     pause(0.1)
    x_e2
    F_e2
%     input('SQP , line 148')
    
end

% x_e 
% x_e2
% 
% F_e
% F_e2
% bfval

% format short e
% error_After1'

format short 

% t_SQP = toc - t_PSO ;

% fprintf('  t_PSO = %4.1f            t_SQP = %4.1f    sec \n\n' , t_PSO , t_SQP )


func_count_SQP = func_count - func_count_PSO ;


% for i_x_1 = 1 : s1+1
%     
%     x_1 = (i_x_1-1)/(s1) ;
%     PF_star_dec(i_x_1,1) = x_1 ;
%     PF_star_dec(i_x_1,2) = 1-sqrt(x_1) ;
%     
% end

% plot(PF_star_dec(:,1),PF_star_dec(:,2))

% [x_e2, F_e2] = sum(error_After1)/size(w,1)




