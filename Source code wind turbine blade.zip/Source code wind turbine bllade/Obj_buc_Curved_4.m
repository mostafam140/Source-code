function [Obj_cr_str]  = Obj_buc_Curved_4(x_x)

lambda = x_x(1) ;   alpha = x_x(2) ;   beta = x_x(3) ;

% lambda = 5.248511 ;   alpha = 0.009915 ;   beta = -0.408970 ;

global  H  r  nu_x  nu_y  E_x  E_y  G_xy  D_yoD_x  D_xyoD_x  DToD_x D_x   n  psi_g


term1 = (D_x/H)*((lambda*n*pi/(n*psi_g*r))^2)*(1+((n/lambda)^4)*(D_yoD_x)+...
        ((n/lambda)^2)*(2*D_xyoD_x+4*DToD_x)) ;
    
term2 = (E_x/(1-nu_x*nu_y))*((alpha^2)+(beta^2)*(E_y/E_x)*((n/lambda)^2) + ...
        2*alpha*beta*nu_y*n/lambda + (1-nu_x*nu_y)*(G_xy/E_x)*((alpha*n/lambda + beta + psi_g/(n*pi))^2) ) ;

Obj_cr_str = (term1 + term2)/(1e6) ;

% input('Obj_buc, line 20')

end

