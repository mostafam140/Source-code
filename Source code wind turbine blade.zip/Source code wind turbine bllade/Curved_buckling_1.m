function [sigma_SQP] = Curved_buckling_1(D)

format short g

global  r  nu_x  nu_y  Q  E1  E_x  E_y  G_xy  D_yoD_x  D_xyoD_x  DToD_x ...
        E_1  nu_12  nu_21  D_x  n  psi_g  H  % H is used in anither m file

% h = 0.015 ;
r = 1.150;      % [m]
nu_x = 0.38 ;
nu_y = 0.14 ;

E_x = Q(1,1) ; % 33.6e9 ;  
E_y = Q(2,2) ; % 12.4e9 ;  % [Pa]

G_xy = Q(3,3) ; % 4.8e9 ;  
D_yoD_x = D(2,2)/D(1,1) ; % 0.3 ;     % D_y/D_x

D_xyoD_x = D(1,2)/D(1,1) ; %  0.087;                   % D_xy/D_x
DToD_x = D(3,3)/D(1,1) ; %  0.086 ;

E_1 = E1 ; % 37.7e9 ;      
nu_12 = 0.29 ;      nu_21 = 0.087 ;
D_x = D(1,1) ; % (E_1*(h^3))/(12*(1-nu_12*nu_21)) ;

n = 1 ;


psi = [1.25 : 0.05 : 1.25] ;

for i_psi = 1 : size(psi,2)
    
    psi_g = psi(i_psi) ;

    [sigma_PSO, popVar_out] = PSO_alg_Curved_2() ;
    
    lambda_PSO(i_psi) = popVar_out(1) ;
    
    alpha_PSO(i_psi) = popVar_out(2) ;
    
    beta_PSO(i_psi) = popVar_out(3) ;
    
    sigma_x_cr_PSO(i_psi) = sigma_PSO ; % (term1 + term2)/(1e6)      % result in MPa
    
    [sigma_SQP, popVar_out_SQP] = SQP_Run_Curved_3(lambda_PSO(i_psi), alpha_PSO(i_psi), beta_PSO(i_psi)) ;
    
    sigma_x_cr_SQP(i_psi) = sigma_SQP ;
    
    fprintf('PSO: lambda  alpha  beta =  %7.6f  %7.6f  %7.6f    \n' , lambda_PSO(i_psi),  alpha_PSO(i_psi),  beta_PSO(i_psi))
    
    fprintf('PSO: Sigma_cr =  %7.4f   \n\n' , sigma_x_cr_PSO(i_psi))
    
    fprintf('SQP: lambda  alpha  beta =  %7.6f  %7.6f  %7.6f    \n' , popVar_out_SQP(1),  popVar_out_SQP(2),  popVar_out_SQP(3))
    fprintf('SQP: Sigma_cr =  %7.4f   \n\n' , sigma_x_cr_SQP(i_psi))
    
end


% fprintf(' sigma =  %7.0f    \n\n' , sigma_x_cr)
format short g
% sigma_x_cr_PSO'


% plot(psi, sigma_x_cr_PSO,'LineWidth',1)       Commented on 98-3-3
% 
% hold on
% 
% % for i_ps = 1 : size(psi,2)
% %     
% %     plot(psi(i_ps), sigma_x_cr_SQP(i_ps),'ro')
% %     
% % end
% 
% set(gca,'FontSize',12) ;
% 
% xlim([0 1.4])
% ylim([0 400])   %  max(400,max(sigma_x_cr))
% 
% xlabel('\psi','FontName','Times New Roman','FontSize',15,'FontWeight','Bold')
% ylabel('Critical stress (MPa)','FontName','Times New Roman','FontSize',14)

end










 