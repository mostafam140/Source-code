function [ Vor ] = inputs()

global  th  Q  U  N_x  N_y  N_xy  a_r  b_s  F1c  F2t  F2c F4 F5 F6  rho  E1  E2  E3  G12  G13  G23  NU12  NU21  NU23  NU31

a_r = 0.508 ;       b_s = 0.127 ;    % [m]

N_x = -1716 ;       N_y = -858.1 ;        N_xy = 0 ;          % [N/m] Lopez, 2009
                    % [N/m] p = 0.2 MPa Data from "RBDO PSO FEA 2013" [Cit 19]

% M_x = 78.13/(20/100) ; 
% M_x = 125/(12.5/100) ;      % [N.m/m]

E1 = 127.55e9 ;      % Data from "Opt. of Laminated Composites ... ", Lopez 2009 
                     % ANSYS Units are MPa & mm, So E1, E2, G and t are                     % evaluated considering these Units.
E2 = 13.03e9 ;

G12 = 6.41e9 ;

NU12 = 0.3 ;       NU21 = NU12*E2/E1 ;

NU31 = NU21 ;       NU23 = NU21 ;

E3 = E2 ;           G13 = G12 ;           G23 = G12 ;

%  Strength (for Tsai-Wu) ------------------------------------------------

%     F1t = 1500e6 ; % x(1) ;
%     F1c = -1500e6  ; % x(2) ;
%     F2t = 48e6 ; % x(3) ;
%     F2c = -246e6 ; % x(4) ;
%     F4 = 0.777*(68e6) ;     % Based on Table 1 of "Reliability formulation for composite ..., 1997"
%     F5 = 68e6 ;             % Based on Table 1 of "Reliability formulation for composite ..., 1997"
%     F6 = 68e6 ; % x(5) ;
    
rho = 1.6e3 ;       % [kg/m^3] This is from general info (no data are found in the paper) 

th = 0.127e-3 ;     % Each layer thickness [m]

Q(1,1) = E1/(1-NU12*NU21) ;             % Based on Liu 2001 
Q(2,2) = E2/(1-NU12*NU21) ;

Q(1,2) = NU12*E2/(1-NU12*NU21) ;

Q(2,1) = Q(1,2) ;
Q(3,3) = G12 ;

% Material Invarients Based on Liu
M = (1/8)*[3  2  3   4
           4  0  -4  0
           1  -2  1  -4
           1  6   1  -4
           1  -2  1   4] ;      % Based on D. liu thesis P. 23 and verified and corrected with Herencia 2007 AIAA Journal

U = M*[ Q(1,1)
        Q(1,2)
        Q(2,2)
        Q(3,3) ] ;

%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


end

