function [F_comp]  = SQP_obj(x)

global  Inde  func_sqp  obj_num  func_count  w  w_dense  f_min  f_max  Ref_point  w_ind

% func_count = func_count + 1 ;

% if funcname == 'dtlz1'

for ii = 1 : 3
    
    x(ii) = round(x(ii)) ;
            
end
        

[f_val,g,x] = func_sqp(obj_num(1),real(x)) 

% f_val
% x
% input('SQP_obj.m , line 20')


F_comp = 0 ;

for i_no = 1 : obj_num
    
    if f_val(i_no) < f_min(i_no)
        f_min(i_no) = f_val(i_no) ;
    end
    
    if f_val(i_no) > f_max(i_no)
        f_max(i_no) = f_val(i_no) ;
    end         
    
    F_Norm(i_no) = (f_val(i_no) - f_min(i_no)) / max((f_max(i_no) -f_min(i_no)),0.0001) ;
    
%     Ref_poi = [0.3  0.3] ;
    
    F_Norm_abs(i_no) = (f_val(i_no) - Ref_point(Inde,i_no)) ; % / (f_max(i_no) - w_dense(Inde,i_no)) ;
    
%     F_Norm_abs(i_no) = (f_val(i_no) - Ref_poi(1,i_no)) / (f_max(i_no) - Ref_poi(1,i_no)) ;
    
%     F_comp = F_comp + (f_val(i_no) - w_dense(Inde,i_no))^2 ;
    
end

% F_comp = sqrt(F_comp) ;

F1 = min(F_Norm) ;

F2 = sum(F_Norm) ;

F3 = (sum(F_Norm_abs.^2))^0.5 ;

% F_comp = F1 + F2 + F3 ;

% d1_c = f_val*w(w_ind,:)' ;    Comment on 97-6-5

F_comp = f_val(1,2) ;    %  d1_c ;     Comment on 97-6-5

end

