function [F_comp]  = DTLZ_SQP_obj(x)

global  Inde  func  obj_num  func_Call  w  w_dense  f_min  f_max  Ref_point  w_ind

func_Call = func_Call + 1 ;

% if funcname == 'dtlz1'

[f_val,g,x] = func(obj_num(1),real(x)) ;

F_comp = 0 ;

for i_no = 1 : obj_num
    
    if f_val(i_no) < f_min(i_no)
        f_min(i_no) = f_val(i_no) ;
    end
    
    if f_val(i_no) > f_max(i_no)
        f_max(i_no) = f_val(i_no) ;
    end         
    
    F_Norm(i_no) = (f_val(i_no) - f_min(i_no)) / max((f_max(i_no) -f_min(i_no)),0.0001) ;
    
%     Ref_poi = [0.3  0.3] ;
    
    F_Norm_abs(i_no) = (f_val(i_no) - Ref_point(Inde,i_no)) ; % / (f_max(i_no) - w_dense(Inde,i_no)) ;
    
%     F_Norm_abs(i_no) = (f_val(i_no) - Ref_poi(1,i_no)) / (f_max(i_no) - Ref_poi(1,i_no)) ;
    
%     F_comp = F_comp + (f_val(i_no) - w_dense(Inde,i_no))^2 ;
    
end

% F_comp = sqrt(F_comp) ;

F1 = min(F_Norm) ;

F2 = sum(F_Norm) ;

F3 = (sum(F_Norm_abs.^2))^0.5 ;

% F_comp = F1 + F2 + F3 ;

d1_c = f_val*w(w_ind,:)' ;

F_comp = d1_c ;

end

