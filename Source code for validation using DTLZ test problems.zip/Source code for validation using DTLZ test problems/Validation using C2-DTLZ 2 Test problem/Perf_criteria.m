function [GD, Delta, MSP, IGD] = Perf_criteria(PFO, PF_star_dec)

global  obj_num  r_c

for I_e = 1 : size(PFO,2)
    
    PF_obtained(:,I_e) = PFO(:,I_e) ;    
    
end

%% Generational Distance (GD)      Ref: Cheng, An Innovative ..., 2016
n = size(PF_obtained,1) ;

sum = 0 ;

for i = 1 : n
    
    % Constraint (97-7-5)                                                
                cons_1 = zeros(1,3) ;                
                summ2 = 0 ;                
                for i_cons = 1 : obj_num                    
                    summ = 0 ;                    
                    for j = 1 : obj_num                        
                        if i_cons ~= j
                            summ = summ + (PF_star_dec(i,j)^2) - (r_c(obj_num)^2) ;
                        end                        
                    end                    
                    cons_1(i_cons) = (PF_star_dec(i,i_cons)-1)^2 + summ ; % + summ ;  % 1 - f_val(3)/0.6 - ( (f_val(1)/0.5) + (f_val(2)/0.5) ) ;                    
                    summ2 = summ2 + ((PF_star_dec(i,i_cons) - 1/sqrt(obj_num))^2) - (r_c(obj_num)^2) ;                    
                end                
                cons_1(obj_num+1) = summ2 ;
                cons = min(cons_1) ;
                
    if cons <= 0            
    
        for j = 1 : size(PF_star_dec,1)

            D_temp(i,j) = sqrt((PF_obtained(i,1)-PF_star_dec(j,1))^2 + (PF_obtained(i,2)-PF_star_dec(j,2))^2) ;
    %         D_temp(i,j) is the  distance of i-th point of PF_know from j-th
    %         point of PF_star.

        end

        D(i) = min(D_temp(i,:)) ;

        sum = sum + D(i)^2 ;
        
    end
    
end
  
GD = (sqrt(sum))/n ;


%% Spread or Delta (Diversity) Juan, a JAVA framawork ..., 2011
n = size(PF_obtained,1) ;
m = size(PF_star_dec,1) ;

PF_obtained = sortrows(PF_obtained) ;

% % Linear
% for i = 1 : (n-1)
%     
%     d_Sp(i) = sqrt((PF_obtained(i+1,1)-PF_obtained(i,1))^2 + (PF_obtained(i+1,2)-PF_obtained(i,2))^2) ;
%       
% end
% 
% d_bar = mean(d_Sp) ;
% 
% sum = 0 ;
% 
% for i = 1 : (n-1)
%     
%     sum = sum + abs(d_Sp(i)-d_bar) ;
%       
% end
% 
% d_f = sqrt((PF_obtained(1,1)-PF_star_dec(1,1))^2 + (PF_obtained(1,2)-PF_star_dec(1,2))^2) ;
% 
% d_l = sqrt((PF_obtained(n,1)-PF_star_dec(m,1))^2 + (PF_obtained(n,2)-PF_star_dec(m,2))^2) ;
% 
% Delta = (d_f + d_l + sum) / (d_f + d_l + (n-1)*d_bar) ;

% Angular, as an idea 
for i = 1 : (n-1)
    
    cos_th_Sp = (PF_obtained(i+1,:)*PF_obtained(i,:)') / (norm(PF_obtained(i+1,:))*norm(PF_obtained(i,:))) ;
    
    theta_Sp(i) = acos(cos_th_Sp) ;
    
end

theta_bar = mean(theta_Sp) ;

sum = 0 ;

for i = 1 : (n-1)
    
    sum = sum + abs(theta_Sp(i)-theta_bar) ;
      
end

cos_th_f = (PF_obtained(1,:)*PF_star_dec(1,:)') / (norm(PF_obtained(1,:))*norm(PF_star_dec(1,:))) ;
    
theta_f = acos(cos_th_f) ;
    
cos_th_l = (PF_obtained(n,:)*PF_star_dec(m,:)') / (norm(PF_obtained(n,:))*norm(PF_star_dec(m,:))) ;
    
theta_l = acos(cos_th_l) ;

Delta = (theta_f + theta_l + sum) / (theta_f + theta_l + (n-1)*theta_bar) ;

  
%% Maximum Spread (MS)      Ref: Cheng, An Innovative ..., 2016
sum = 0 ;

for i = 1 : 2
    
    f_max(i) = max(PF_obtained(:,i)) ;
    f_min(i) = min(PF_obtained(:,i)) ;
    
    F_max(i) = max(PF_star_dec(:,i)) ;
    F_min(i) = min(PF_star_dec(:,i)) ;
    
    sum = sum + ((min(f_max(i),F_max(i))-max(f_min(i),F_min(i)))/(F_max(i)-F_min(i)))^2 ;
    
end

MSP = sqrt(0.5*sum) ;


%% Inverted Generational Distance (IGD)      Ref: Ishibuchi, Difficulties in ..., 2014, and  Juan, a JAVA framawork ..., 2011, and 
n = size(PF_star_dec,1) ;

sum = 0 ;

for i = 1 : n
    
    % Constraint (97-7-5)                                                
                cons_1 = zeros(1,3) ;                
                summ2 = 0 ;                
                for i_cons = 1 : obj_num                    
                    summ = 0 ;                    
                    for j = 1 : obj_num                        
                        if i_cons ~= j
                            summ = summ + (PF_star_dec(i,j)^2) - (r_c(obj_num)^2) ;
                        end                        
                    end                    
                    cons_1(i_cons) = (PF_star_dec(i,i_cons)-1)^2 + summ ; % + summ ;  % 1 - f_val(3)/0.6 - ( (f_val(1)/0.5) + (f_val(2)/0.5) ) ;                    
                    summ2 = summ2 + ((PF_star_dec(i,i_cons) - 1/sqrt(obj_num))^2) - (r_c(obj_num)^2) ;                    
                end                
                cons_1(obj_num+1) = summ2 ;
                cons = min(cons_1) ;
                
    if cons <= 0
        for j = 1 : size(PF_obtained,1)
            
            sum0 = 0 ;
            
            for i_objnum = 1 : obj_num
                
                sum0 = sum0 + (PF_star_dec(i,i_objnum)-PF_obtained(j,i_objnum))^2 ;
                
            end

            d_temp(i,j) = sqrt(sum0) ;
          % d_temp(i,j) is the  distance of i-th point of PF_star_dec from j-th point of PF_know

        end
        
        d(i) = min(d_temp(i,:)) ;
        
        sum = sum + d(i) ;
        
    end
    
end
  
IGD = (sum)/n ;

%     sum_er1 = 0 ;
%     for re_cn = 1 : obj_num
%     	sum_er1 = sum_er1 + (f_val(re_cn)-w_dense(w_ind,re_cn))^2 ;
%     end
%     error_After1(w_ind) = sqrt( sum_er1 ) ;    
%     IGD_PSO = sum(error_After1)/size(w_dense,1) ;
    
    
    