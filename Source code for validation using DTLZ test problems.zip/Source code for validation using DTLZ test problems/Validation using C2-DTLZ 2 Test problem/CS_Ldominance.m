function [CS] = CS_Ldominance(x_e2, F_e2)

global  w_dense  obj_num

[x_e3, F_e3] = SQP_Run(w_dense, F_e2, x_e2) ;     % Gbest are global best variables

CSn = 0 ;

for i_c = 1 : size(F_e2,1)
    
    for j_c = 1 : size(F_e3,1)
        
        B_t = 0 ;   W_s = 0 ;
        
        for k_c = 1 : obj_num
        
            if F_e3(j_c,k_c)<F_e2(i_c,k_c)
                
                B_t = B_t + 1 ;
                
            elseif F_e2(j_c,k_c)<F_e3(i_c,k_c)
                
                W_s = W_s + 1 ;
                
            end
            
        end
        
        if (B_t-W_s)>=0  &&  sum(F_e3(j_c,:))<=sum(F_e2(i_c,:))            
            
           CSn = CSn + 1 ;
           
           break
           
        end
       
    end
        
end

CS = CSn / size(F_e2,1)



    
    
    