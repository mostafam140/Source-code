function [c, ceq] = DTLZ_SQP_nonlcon(x)

global  Inde  w  W_T  func  funcname  obj_num  w_ind  r_c

% if funcname == 'dtlz1'

    [f_val,g,x] = func(obj_num(1),real(x)) ;
    
%     elseif funcname == 'dtlz2'
        
%         [f_val,g,x] = dtlz2(obj_num(1),real(x)) ;
        
% end  

% anda = norm(W_T(p1,:)) ;

d1 = f_val*w(Inde,:)' ;

d2 = sqrt(abs((norm(f_val))^2-d1^2)) ;

cos_th = (f_val*w(Inde,:)') / (norm(f_val)*norm(w(Inde,:))) ;

theta = acosd(cos_th) ;

if w_ind == 1
    
    c_t = theta - 0.005 ;
    
else
    
    c_t = theta - 0.1 ;
    
end

% Constraint (97-7-5)
cons_1 = zeros(1,3) ;
                
                summ2 = 0 ;
                
                for i_cons = 1 : obj_num
                    
                    summ = 0 ;
                    
                    for j = 1 : obj_num
                        
                        if i_cons ~= j
                            summ = summ + (f_val(j)^2) - (r_c(obj_num)^2) ;
                        end
                        
                    end
                    
                    cons_1(i_cons) = (f_val(i_cons)-1)^2 + summ ; % + summ ;  % 1 - f_val(3)/0.6 - ( (f_val(1)/0.5) + (f_val(2)/0.5) ) ;
                    
                    summ2 = summ2 + ((f_val(i_cons) - 1/sqrt(obj_num))^2) - (r_c(obj_num)^2) ;
                    
                end
                
                cons_1(obj_num+1) = summ2 ;
                
                cons = min(cons_1) ; % max([cons_1 summ2]) ;

c = [c_t
     cons] ;

ceq  = [] ;

% % The test Problem: DTLZ 1
% 
% K = 5 ; M = 3 ;
% 
%     sum = 0 ;
%     
%     for jj = M : (M+K-1)
%         
%         sum = sum + (x(jj)-0.5)^2 - cos(20*pi*(x(jj)-0.5)) ;
%         
%     end
% 
%     g = 100*(K + sum) ;  % 5 is K parameter and set to 5 based on NSWU A Decomposition Based ..., Asafuddoula, 2014  1 + 9*sum(popVar(i,2:numVar))/(numVar-1);
%     
%     f1 = 0.5*x(1)*x(2)*(1+g) ;
% 
%     f2 = 0.5*x(1)*(1-x(2))*(1+g) ;
% 
%     f3 = 0.5*(1-x(1))*(1+g) ;
%         
% %     for j = 1 : size(W,1)
%         
%         d1 = f1*w(ghj,1) + f2*w(ghj,2) + f3*w(ghj,3) ;
%                 
%         d2 = sqrt((f1^2 + f2^2 + f3^2) - d1^2) ;
%         
%         if ((f1^2 + f2^2 + f3^2) - d1^2 < 0)
%                         
%             d2 = 0 ;            
%             
%         end
%         
%         if ((f1^2 + f2^2 + f3^2) - d1^2 < -0.05)
%             
%             (f1^2 + f2^2 + f3^2) - d1^2
%             d2
%             d2 = 0 ;
%             input('line 40  DTLZ_1_SQP_nonlcon(x) ')
%             
%         end                        
        
% %     end
    
end
