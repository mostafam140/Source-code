clc

clear all
% clearvars -except popVar_in

global w Inde  obj_num  w_dense  func  func_count  f_min  f_max  d1_bestg  d2_bestg  lb  ub  var_num  ...
    d1_bestp  v_old  Pbest  Gbest  pop_size   Gen_max   gen   Total_best_F_Comp   X_Total  Pareto_sol  ...
    s1  func_count_PSO  func_count_SQP  r_c

% rand('twister', 100);

format short

tic

func = str2func('dtlz2') ;         % PoMoSt: Location Problem: Pollution Monitoring Station, Ref: S. Mohammadi 2017,  Miettinen 2006

obj_num = 3 ;

f_min = 500*ones(1,obj_num) ;        f_max = zeros(1,obj_num) ;

var_num = obj_num + 10 - 1 ;    % NOTE 10: K should be check for other dtlz

s1 = 12 ;
s2 = 0 ;    % upper level spacing

func_count = 0 ;

def.popSize = obj_num ;

[def.popSize,w] = direction_vector(s1, s2, obj_num) 
w_dense = w ;

Gen_max = 250 ;   pop_size = 91 ;


lb = zeros(1,var_num) ;
ub = ones(1,var_num) ;

% w_dense = zeros(obj_num,obj_num) ;
% 
% for i_w_d = 1 : obj_num
%     
%     w_dense(i_w_d,obj_num-i_w_d+1) = 1 ;
%     
% end

% di = 1 ;    w_dense = w_dense/di ;

% w_dense = w_dense./norm(w_dense) 

% w = 0.5*w ;
for i_w = 1 : size(w_dense,1)
    
    w_dense(i_w,:) = w(i_w,:)./norm(w(i_w,:)) ;
    
    popVar = rand(pop_size,var_num) ;       % According to [1]
    
    popVar(:,1) = popVar(:,1)*(ub(1)-lb(1)) + lb(1) ;
    
    popVar(:,2) = popVar(:,2)*(ub(2)-lb(2)) + lb(2) ;
    
    popVar_in = popVar ;
    
    Pbest(1:pop_size,1:var_num) = popVar ; %1000 ;
    Gbest(i_w,1:var_num) = popVar(1,1:var_num) ; %1000 ;
    d1_bestg(i_w) = 1000 ;
    
    d2_bestg(i_w) = 1000 ;
    
end

% w_dense = zeros(obj_num,obj_num) ;
% 
% for i_w_d = 1 : obj_num
%     
%     w_dense(i_w_d,obj_num-i_w_d+1) = 1 ;
%     
% end

di = 1 ;    w_dense = w_dense/di ;

% w_dense = w_dense./norm(w_dense) 

% w(i_w,:) = w(i_w,:)./norm(w(i_w,:)) ;

% input('PSO_test.m line 75')

for w_ind = 1 : 1 % size(w_dense,1)
    
    Inde = w_ind ;
    Total_best_F_Comp = 1000 ;        
        
    d1_bestp(1:pop_size) = 1000 ;
    d2_bestp(1:pop_size) = 1000 ;
    v_old(1:pop_size,1:var_num) = rand(pop_size,var_num) ;
    
    MSInd = 0 ;            % Multi-Start Index
    
%     I_sort = [1:1:pop_size] ;
    
    for gen = 1 : Gen_max
        MSInd = MSInd + 1 ;
%%                               Multi-Start Strategy

%             clearvars -except popVar_in  obj_num  pop_size  var_num  w_ind  gen  func  di  w_dense  Inde
            
            MSCrit = 200*(1-0.5*gen/Gen_max) ;
            
            if (gen < ceil(0.7*Gen_max))  &&  (MSInd > MSCrit)  &&  abs(bestgMS(gen-100)-bestgMS(gen-1)) < 0.1
                MSInd = 0 ;
                
                fprintf('\n --  Re-Initialization  --  --  Re-Initialization  --  --  Re-Initialization  -- \n')
                f_min = 500*ones(1,obj_num) ;        f_max = zeros(1,obj_num) ;
%                popVar = popVar_in ;
                
                popVar = rand(pop_size,var_num) ;
                
                Pbest(1:ceil(0.5*pop_size),1:var_num) = popVar(1:ceil(0.5*pop_size),:) ; %1000 ;
                Gbest(w_ind,1:var_num) = popVar(1,1:var_num) ; %1000 ;
                d1_bestg(w_ind) = 1000 ;
                d2_bestg(w_ind) = 1000 ;
                d1_bestp(1:pop_size) = 1000 ;
                d2_bestp(1:pop_size) = 1000 ;
                v_old(1:ceil(0.5*pop_size),1:var_num) = rand(ceil(0.5*pop_size),var_num) ;
            end
               
        
        
        omega = 0.7298 ; % 0.09 - (0.05)*(gen/Gen_max) ;
        
        x_old_in = popVar_in ;        
        
        [ popVar_in, I_sort ] = PSO_alg( x_old_in , omega , w_ind) ;
        
        bestgMS(gen) = d1_bestg(w_ind) ;
        
        if mod(gen , 15) == 0
            
            fprintf(' gen =  %5.0f       F_comp = %6.3f  ' , gen , d1_bestg(w_ind) )        
            
            fprintf('\n---------------------------------  \n')
        end
        
%         figure(1)
        
%         fp1 = plot3(Pareto_sol(:,1), Pareto_sol(:,2), Pareto_sol(:,3),'o','LineWidth',1,...
%         'MarkerEdgeColor','k',...
%         'MarkerFaceColor','g',...
%         'MarkerSize',6) ;
        
%         xlim([0  1.1])
%         ylim([0  ceil(max(Pareto_sol(:,2)))])
        
%         set(gca,'FontName','Times New Roman','FontSize',13) ;
        
%         xlabel('f_1','FontName','Times New Roman','FontSize',13,'FontAngle','italic')
%         ylabel('f_2','FontName','Times New Roman','FontSize',13,'FontAngle','italic')
%         zlabel('f_3','FontName','Times New Roman','FontSize',13,'FontAngle','italic')

%         hold on
%         grid on        
        
%         pause(0.01)
    

        
    end
    
    
    [f_val,g,x] = func(obj_num(1),X_Total(w_ind,1:var_num)) ;
    x
    f_val
    
    
    x_e(w_ind,:) = x ;
    F_e(w_ind,:) = f_val ;   
    
    
    fprintf('  norm(f_val) = %7.4f  \n' , norm(f_val) )
    
    
    d_1(w_ind) = di*f_val*w_dense(Inde,:)' ;
    
    d_2(w_ind) = sqrt(abs((norm(f_val))^2-d_1(w_ind)^2)) ;    
    
    
    bfval(w_ind,:) = f_val ;
    
    fprintf('  ------------------   END   ------------------   w_ind = %5.1f  \n' , w_ind )
    
end

Pareto_sol

F_e

x_e

% Here, decomposed PF_star is obtained for using in IGD calculation
for i_x_1 = 1 : size(w_dense,1)
    
    PF_star_IGD(i_x_1,:) = w_dense(i_x_1,:) ;
    
    figure(1)
        
    fp2 = plot3(PF_star_IGD(i_x_1,1), PF_star_IGD(i_x_1,2),PF_star_IGD(i_x_1,3),'*','LineWidth',1,...
        'MarkerEdgeColor','r',...
        'MarkerFaceColor','k',...
        'MarkerSize',6) ;
    
    
%     legend([fp7 fp1 fp2],'Infeasible points','Feasible points','True Pareto','Location','northwest')
    
end

[GD_PSO, Delta_PSO, MSP_PSO, IGD_PSO] = Perf_criteria(Pareto_sol, PF_star_IGD) ;

fprintf('  ------------   PSO Finished   ------------  PSO_fun_call = %10.1f  \n'  ,  func_count)

hold on


% [GD_PSO, Delta_PSO, MSP_PSO, IGD_PSO] = Perf_criteria(Pareto_sol, PF_star_IGD) ;


% figure(2)

[ Fig ] = Untitled3()

% fp3 = plot3(PF_star_IGD(i_x_1,1), PF_star_IGD(i_x_1,2),PF_star_IGD(i_x_1,3),'*','LineWidth',1,...
%         'MarkerEdgeColor','r',...
%         'MarkerFaceColor','k',...
%         'MarkerSize',5) ;
% grid on
% hold on

% plot3(w_dense(:,1), w_dense(:,2), w_dense(:,3), 'r*')

w_dense
bfval


[x_e2, F_e2] = SQP_Run(w_dense, Pareto_sol, Gbest) ;     % Gbest are global best variables

r_time = toc ;

x_e2

F_e2

% Constraint 

cons_1 = 0 ;        summ2 = 0 ;

for st = 1 : size(F_e2,1)
    
    f_val = F_e2(st,:) ; % [A(st)  sqrt(1-A(st)^2)] ;
    
    summ2 = 0 ;
    for i_cons = 1 : obj_num
        summ = 0 ;
                    for j = 1 : obj_num                        
                        if i_cons ~= j
                            summ = summ + (f_val(j)^2) - (r_c(obj_num)^2) ;
                        end
                    end
                    
                    cons_1(st, i_cons) = (f_val(i_cons)-1)^2 + summ  ; % + summ ;  % 1 - f_val(3)/0.6 - ( (f_val(1)/0.5) + (f_val(2)/0.5) ) ;
                    
                    summ2 = summ2 + ((f_val(i_cons) - 1/sqrt(obj_num))^2) - (r_c(obj_num)^2) ;
                    
    end
    cons_1(st,obj_num+1) = summ2 ;        
    
    if min(cons_1(st,:)) <= 0
        figure(2)
        fp4 = plot3(F_e2(st,1), F_e2(st,2), F_e2(st,3),'o','LineWidth',1,...
                                    'MarkerEdgeColor','k',...
                                    'MarkerFaceColor','b',...
                                    'MarkerSize',6) ;
        grid on
        hold on
    end
end

cons_1
% figure(1)

% fp5 = plot3(w_dense(:,1), w_dense(:,2), w_dense(:,3), 'r*')
% 
% legend([fp1 fp2],'Feasible points','True Pareto','Location','northwest')


figure(2)

legend([fp2 fp4],'True Pareto','Pareto solutions (SQP)','Location','northwest')


% input('SQP is finished')

func_count_PSO_2 = func_count_PSO ;

func_count_SQP_2 = func_count_SQP ;


% [CS_SQP] = CS_Ldominance(x_e2, F_e2) ;
% 
% fprintf('\n    Two set coverage (CS SQP)                  %6.5f    \n' , CS_SQP )


[GD_SQP, Delta_SQP, MSP_SQP, IGD_SQP] = Perf_criteria(F_e2, PF_star_IGD) ;

fprintf('\n                                            PSO        SQP   \n')

fprintf('\n    Spread (Delta)                         %5.4f    %6.5f  \n' , Delta_PSO , Delta_SQP )

fprintf('\n    Maximum Spread                         %5.4f    %6.5f  \n' , MSP_PSO , MSP_SQP )

fprintf('\n    Generational Distance(GD)    %5.4f    %7.6f  \n' , GD_PSO , GD_SQP )

fprintf('\n    Inverted Generational Distance(IGD)    %5.4f    %7.6f  \n' , IGD_PSO , IGD_SQP )

fprintf('\n    NFE =              %7.0f    %7.0f    \n\n' , func_count_PSO_2 , func_count_SQP_2 ) % NFE: The Number of Function Evaluations

fprintf('\n  Run time (sec) =                 %7.0f   \n\n' , r_time )


 

%%            Sub-Functions

function [n,w] = direction_vector(s1,s2,m)
[n,w] = gen_weight(s1,m);
if s2 > 0
    [n2,w2] = gen_weight(s2,m);
    n = n+n2;
    w = [w;w2*0.5+(1 - 0.5)/(m)];
end
return
end

% Generating the direction vectors
function [n,w]=gen_weight(p,M)
NumPoints((1:M-1))=p;
% partitioned into the first objective
Beta1 = (0:(NumPoints(1)))'/(NumPoints(1));
Beta = Beta1;
for i = 2:M-1
    ki = round((1-sum(Beta1,2))*(NumPoints(i)));
    Beta = [];
    for j =1:size(Beta1,1)
        BetaVec = (0:ki(j))'/(NumPoints(i));
        Beta = [Beta; [repmat(Beta1(j,:), length(BetaVec),1) BetaVec] ];
    end
    Beta1 = Beta;
end
w= [Beta (1 - sum(Beta1,2))]; 
n=size(w,1);
return
end
