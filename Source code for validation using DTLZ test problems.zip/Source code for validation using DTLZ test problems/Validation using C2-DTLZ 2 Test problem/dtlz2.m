function [f,g,x] = dtlz2(objnum,x)

global func_count

func_count = func_count + 1 ;
% nargin = 0 ;
if nargin == 1

	prob.nf = objnum;
	prob.ng = 0;
    prob.k=10;    
	prob.nx = prob.nf+prob.k-1;
    
	for i = 1:prob.nx
		prob.range(i,:) =  [0,1];
	end
	f = prob;
%     g = [];      % Added in 9-7-96
else
	[f,g] = dtlz2_true(x,objnum);
end
return
function [f,g] = dtlz2_true(x,objnum)

M = objnum;
k = 10;
temp = x(:,M:M+k-1)-0.5;
G = sum(temp.^2,2);
temp1 = x(:,1:M-1)*pi/2;
f(:,1) = (1+G).*prod(cos(temp1),2);
for j = 2:M-1
    f(:,j)= (1+G).*prod(cos(temp1(:,1:M-j)),2).*sin(temp1(:,M-j+1));
end
f(:,M) = (1+G).*sin(x(:,1)*pi/2);

% for i=1:objnum
%     f(:,i) = 1.0*(1+G)-f(:,i);
% end

g = [];
 
 return