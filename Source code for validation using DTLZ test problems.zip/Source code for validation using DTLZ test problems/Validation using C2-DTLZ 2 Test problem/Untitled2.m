clc
clear all
r_c = [0.3 0.2 0.4 4 0.5 6 7 0.5 9 0.5 11 12 13 14 0.5] ;

a = [0.3 0.954] ;       b = [1 0] ;     c = [0 1] ;   d = [0.707 0.707] ;

for i_th = 1 : 21
    
    theta = ((i_th-1)/20)*90 ;

    A(i_th) = 1*cosd(theta) ;

end

% f_val = d ;
obj_num = 2 ;
%      mean(f_val)
                
cons_1 = 0 ;

summ2 = 0 ;

for st = 1 : size(A,2)
    st
    f_val = [A(st)  sqrt(1-A(st)^2)] ;
    
    summ2 = 0 ;
    for i_cons = 1 : obj_num
        summ = 0 ;
                    for j = 1 : obj_num                        
                        if i_cons ~= j
                            summ = summ + (f_val(j)^2) - (r_c(obj_num)^2) ;
                        end                        
                    end                                        
                    
                    cons_1(st, i_cons) = (f_val(i_cons)-1)^2 + summ  ; % + summ ;  % 1 - f_val(3)/0.6 - ( (f_val(1)/0.5) + (f_val(2)/0.5) ) ;
                    
                    summ2 = summ2 + ((f_val(i_cons) - 1/sqrt(obj_num))^2) - (r_c(obj_num)^2) ;
                    
    end
    cons_1(st,3) = summ2 ;
    if min(cons_1(st,:)) <= 0 
        plot(f_val(1) , f_val(2),'o','LineWidth',1,...
                                    'MarkerEdgeColor','k',...
                                    'MarkerFaceColor','b',...
                                    'MarkerSize',6) ;
        hold on
    else
        plot(f_val(1) , f_val(2),'o','LineWidth',1,...
                                    'MarkerEdgeColor','k',...
                                    'MarkerFaceColor','r',...
                                    'MarkerSize',6) ;
        hold on
    end
end

                
%                 cons_1(:)
%                 summ2
cons_1
% summ2
%                 cons = max([cons_1 summ2]) 
                