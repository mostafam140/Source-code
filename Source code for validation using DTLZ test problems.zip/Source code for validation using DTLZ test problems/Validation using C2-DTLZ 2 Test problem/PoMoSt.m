function [f,g,x] = ZDT1(objnum,x)  % [f1, f2] = Obj_f(i,popVar)

global func_count

func_count = func_count + 1 ;

numVar = length(x) ;

% x
% input('10 PoMoSt')

g = 1 ;

% [phi_num] = PHI_func(x(1),x(2)) ;

f(1) = PHI_func(x(1),x(2)) ;

f(2) = PHI_func((x(1)-1.2),(x(2)-1.5)) ;

f(3) = PHI_func((x(1)+0.3),(x(2)-3.0)) ;

f(4) = PHI_func((x(1)-1.0),(x(2)-0.5)) ;

f(5) = PHI_func((x(1)-0.5),(x(2)-1.7)) ;

% figure(2)
% 
% plot([1 2 3 4 5] , [f(1) f(2) f(3) f(4) f(5)])
%                 
% pause(0.1)
% 
% hold on
        
function [phi_num] = PHI_func(x1,x2)
    
    phi_num = -3*((1-x1)^2)*(exp(-x1^2-((x2+1)^2))) + 10*(0.25*x1-(x1^3)-(x2^5))*(exp(-x1^2-x2^2))-(1/3)*(exp((-(x1+1)^2)-x2^2)) ;
        
return
end


end





