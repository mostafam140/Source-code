function [ popVar_out , I_sort ] = PSO_alg( x_old_in , omega , ghj)

global v_old  w_dense  func  obj_num  Pbest  d1_bestp  Gbest  d1_bestg ...
       var_num  Total_best_F_Comp  X_Total  Pareto_sol  fp7  ub  lb  r_c


cos_th_dis = (w_dense(1,:)*w_dense(2,:)') / (norm(w_dense(1,:))*norm(w_dense(2,:))) ;

theta_dis = acosd(cos_th_dis)/2 ;

for i = 1 : size(x_old_in , 1)       
        
%         F_Comp_alg(i) = DTLZ_PSO_obj(x_old_in(i,:)) ;        
        [f_val, g, x] = func(obj_num(1), x_old_in(i,1:var_num)) ;
        
        for i_w = 1 : size(w_dense,1)
            
            cos_th = (f_val*w_dense(i_w,:)') / (norm(f_val)*norm(w_dense(i_w,:))) ;
            
            theta = acosd(cos_th) ;            
            
%             if mod(gen , 15) == 0
%                 fprintf('  theta =   %10.0f    gen = %10.0f\n' , theta , gen )
%             end
            
            if theta < theta_dis   %  (90/(size(w_dense,1)-1))
                
                Pro_f_on_w = f_val*w_dense(i_w,:)' ;        % Pro_f_on_w is the projection of f_val on w_dense 
                
                
                % Constraint (97-7-5)                
                                
%                 cons_1 = zeros(1,3) ;
                
                summ2 = 0 ;
                
                for i_cons = 1 : obj_num-1
                    
%                     summ = 0 ;
                    
%                     for j = 1 : obj_num
%                         
%                         if i_cons ~= j
%                             summ = summ + (f_val(j)^2) - (r_c(obj_num)^2) ;
%                         end
%                         
%                     end
                    
%                     cons_1(i_cons) =  summ ;  % 1 - f_val(3)/0.6 - ( (f_val(1)/0.5) + (f_val(2)/0.5) ) ;
                    
                    summ2 = summ2 + (f_val(i_cons)/0.5) ;
                    
                end
                
%                 cons_1(obj_num+1) = summ2 ;
                
                cons = 1 ; % - f_val(obj_num)/0.6 - summ2 ;
                
%                 input('PSO_alg, line 51')
                if cons < 0
%                 fprintf('\n In-feasible')
                    if Pro_f_on_w < 1.1
                        
                        figure(1)    
                        
                        fp7 = plot3(f_val(1), f_val(2), f_val(3),'o','LineWidth',1,...
                                    'MarkerEdgeColor','k',...
                                    'MarkerFaceColor','r',...
                                    'MarkerSize',6) ;
                        
                        grid on
                        hold on
                    
                    end

                    Pro_f_on_w = Pro_f_on_w + 1 + abs(cons) ;

                else % if Pro_f_on_w < 1.1   % max([f_val(1), f_val(2), f_val(3)]) < 0.65
%                     fprintf('\n Feasible')
%                     figure(1)    
% 
%                         plot3(f_val(1), f_val(2), f_val(3),'o','LineWidth',1,...
%                                     'MarkerEdgeColor','k',...
%                                     'MarkerFaceColor','b',...
%                                     'MarkerSize',6)
% 
%                         grid on
%                         hold on

%                         pause(0.001)
                
                end





                if Pro_f_on_w < d1_bestp(i)
                    
                    d1_bestp(i) = Pro_f_on_w ;
                    Pbest(i,1:var_num) = x_old_in(i,1:var_num) ;
                    
                end
                
                if ( Pro_f_on_w < d1_bestg(i_w)) && (cons > 0)  %  d2_cc(i,ghj) < min(d1_cc(i,ghj),d2_bestg(ghj))   % && ( d2_cc(i,ghj) < d2_bestg(i) )
            
                    d1_bestg(i_w) = Pro_f_on_w ;                        
                    Gbest(i_w,1:var_num) = x_old_in(i,1:var_num) ;
                    Pareto_sol(i_w,:) = f_val ;
                    
                end
                
                if Pro_f_on_w < Total_best_F_Comp
                    
                    X_Total(i_w,1:var_num) = x_old_in(i,:) ;
                    Total_best_F_Comp = Pro_f_on_w ;
                    
                end
                
                
%                 %%                               Mutation
% 
%                     num_affected = randi(var_num) ; % ceil(var_num*(1-sqrt(gen/Gen_max))) ;
% 
%                     affected_inices = randperm(var_num,num_affected) ;
% 
%                     for i_num_popsize = 1 : ceil(0.1*pop_size)    %   ceil(pop_size*(1-sqrt(gen/Gen_max)))
% 
%                         popVar_in(i_num_popsize,:) = Gbest(i_w,1:var_num) ;
% 
%                         for i_mut = 1 : num_affected
% 
%                             whichdim = affected_inices(i_mut) ;      % randi(var_num) ;
% 
%                             mutrate = 0.5 ;
% 
%                             mutrange = (ub(whichdim) - lb(whichdim))*((1-gen/Gen_max)^(5/mutrate)) ;
% 
% %                             ub_mut = popVar_in(whichdim) + mutrange ;
% %                             lb_mut = popVar_in(whichdim) - mutrange ;
% 
%             %                 if lb_mut < lb(whichdim)
%                                 lb_mut = lb(whichdim) ;
%             %                 end
% 
%             %                 if ub_mut > ub(whichdim)
%                                 ub_mut = ub(whichdim) ;
%             %                 end
% 
%                             x_old_in(i_num_popsize, whichdim) = rand*(ub_mut-lb_mut) + lb_mut ;
% 
%                         end           
%                         
%                     end
        
        
        
        
        
                break                
                
            end
            
        end
        
% %         if ( F_Comp_alg(i) < d1_bestp(i) )          comented on 97-5-23
% %             
% %             d1_bestp(i) = F_Comp_alg(i) ;
% %             Pbest(i,1:var_num) = x_old_in(i,1:var_num) ;
% %             
% %         end
% %         
% %         if ( F_Comp_alg(i) < d1_bestg(ghj)) % &&  d2_cc(i,ghj) < min(d1_cc(i,ghj),d2_bestg(ghj))   % && ( d2_cc(i,ghj) < d2_bestg(i) )
% %             
% %             d1_bestg(ghj) = F_Comp_alg(i) ;                        
% %             Gbest(ghj,1:var_num) = x_old_in(i,1:var_num) ;
% %         end
% %         
% %         if F_Comp_alg(i) < Total_best_F_Comp            
% %             X_Total(ghj,1:var_num) = x_old_in(i,:) ;
% %             Total_best_F_Comp = F_Comp_alg(i) ;            
% %         end
            
	
%     end
    
    Randd = randperm(var_num) ;

    for j = 1 : size(x_old_in , 2)        % size(x_old_in,2) = var_num                
        
        rang = size(Pbest,1) ;

        gBest = randperm(rang) ;            gBest_indx = gBest(1) ;


%         v_new(i,j) = omega*v_old(i,j) + c1*rand*(Pbest(i,j)-x_old_in(i,j)) + c2*rand*(Gbest(ghj,j)-x_old_in(i,j)) ;
        phi1 = 2.05*rand(1) ;    phi2 = 2.05*rand(1) ;
        
        v_new(i,j) = omega*( v_old(i,j) + phi1*(Pbest(i,j)-x_old_in(i,j)) + phi2*(Pbest(gBest_indx,j)-x_old_in(i,j)) ) ;
%         if j > Randd(1) && gen > Gen_max/2
%             v_new(i,j) = 0 ;
%         end
        
        popVar_out(i,j) = x_old_in(i,j) + v_new(i,j)*1 ;
        
        if popVar_out(i,j) < lb(j)
            
            r = 1-(popVar_out(i,j)/min(popVar_out(:,j))) ;
            if r < 0
                r
                input('PSO_alg.m, line 144')
            end
            popVar_out(i,j) = 0 + r*(ub(j)-lb(j)) + lb(j) ; % rand/2 ;    % Changed on 97-3-30
            
        elseif popVar_out(i,j) > ub(j)
            
            r = 1-(popVar_out(i,j)/max(popVar_out(:,j))) ;
            if r > 1
                r
                input('PSO_alg.m, line 153')
            end
            popVar_out(i,j) = (1 - r)*(ub(j)-lb(j)) + lb(j) ; % (rand+1)/2 ;   % Changed on 97-3-30
            
        end
                
    end
    
end


[~,I_sort] = sort(Pro_f_on_w) ;


v_old = v_new ;

end


% if gen < 200
%     
%     MaxFuncEval = 1 ;
%     
% else
%     
%     MaxFuncEval = 1 ;
%     
% end
%     
%     
% for i_2 = 1 : size(x_old_in , 1)
%    
%     % Pbest     Pbest   Pbest
%     % trust-region-reflective algorithm is a large-scale algorithm
%     
%     options = optimset('LargeScale','on' , 'Algorithm' , 'active-set' , 'MaxIter',300,...
%     'MaxFunEvals',MaxFuncEval,'TolFun',1e-6,'TolX',1e-6,'Diagnostics','off','Display','off') ; % , 'Algorithm','sqp'   ,'Algorithm','LargeScale')  'MaxFunEvals',350,   'PlotFcns',@optimplotfval,
%     
%      x0 = x_old_in(i_2,:) ;
        
    
%     fprintf('  x0 (initial) = %6.3f  %6.3f  %6.3f  %6.3f  %6.3f  %6.3f  %6.3f \n' , x0 )  
    
%     x0(1,:) = [0.5  0.5  0.5  0.5  0.5  0.5  0.5] ;
%     x0(1,5) = 0.5 ;

% p1 = randperm(size(x_old_in , 1)) ;

% [x0] = realbinary_crossover(x_old_in,i_2,p1(i_2),ub,lb) ;


%         if gen > 30       % Novel multi-parent crossover [Particle swarm optimization with crossover: a review
%                           % and empirical analysis, 2016]
%             
%             counticon = randi(7,[1  i_2]) ;
%             
%             if i_2 > 7
%                 
%                 input('63 PSO_alg')
%                 i_2
%                 x_old_in(i_2,:)
%                 counticon
%             
%             end
%             
%             for countfor = 1 : i_2            
%                 
%                 counti = counticon(countfor) ; % ceil(7*rand) ;
%                 
%                 x0(counti) = Gbest_par(ghj,counti) + 0.5*rand*((-1)^gen) ;  %  ( rand*x_old_in(i,j) + rand*x_old_in(i-1,j) + rand*x_old_in(i-2,j) + rand*x_old_in(i-3,j) )/2 ;
%                 
%                 if x0(counti) < 0
% 
%                     x0(counti) = x0(counti) + 0.5 ;
% 
%                 elseif x0(counti) > 1
% 
%                     x0(counti) = x0(counti) - 0.5 ;
% 
%                 end
%             
%             end
%                                 
% %             fprintf('  mutated x0   = %6.3f  %6.3f  %6.3f  %6.3f  %6.3f  %6.3f  %6.3f \n\n' , x0 )  
%                        
%         end
        
%     x_old_in
%     x = x0 ;
    
%     [x, fval, exitflag, output_1] = fmincon(@DTLZ_1_SQP_d1_d2,x0,[],[],[],[],lb,ub,@DTLZ_1_SQP_nonlcon,options) ;
% x
% input('127')
    %     x = x_old_in ;      % Mos
    
%     output_1
%     input('output 101')
%     Pbest_d1(i,j) = DTLZ_1_d1_d2(x)

%             Pbest_par(i_2,:) = x(1:7) ;
%             
%     [at, bt, ct] = DTLZ_1(x(1:7)) ;    % t for Temporary 
%     
%     F(i_2,1:3) = [at, bt, ct] ;
%     
%     for j = ghj : ghj % 1 : size(W,1)
%         
%         d1_cc(i_2,j) = F(i_2,1)*w(j,1) + F(i_2,2)*w(j,2) + F(i_2,3)*w(j,3) ;  % c denotes child
%         
%         d2_cc(i_2,j) = sqrt((F(i_2,1)^2 + F(i_2,2)^2 + F(i_2,3)^2) - d1_cc(i_2,j)^2) ;
%         
% %         d2tod1(i,j) = d2_c(i,j)/d1_c(i,j) ;
%         
%     end
    
%     if ( d1_cc(i_2,ghj) < Gbest(ghj)) && ( d2_cc(i_2,ghj) < 0.05 )
%         
%         Gbest(ghj) = d1_cc(i_2,ghj) ; %+10*d2_cc(i_2,ghj) ;
%         
%         d1best(ghj) = d1_cc(i_2,ghj) ;
%         
%         d2best(ghj) = d2_cc(i_2,ghj) ;
%         
%         Fbest(ghj,:) = F(i_2,:) ;
%         
%         Gbest_par(ghj,:) = x(1:7) ;
%         
%     end
    
    
%     Gbest_par_mut(ghj,:) = Gbest_par(ghj,:) ;
    


