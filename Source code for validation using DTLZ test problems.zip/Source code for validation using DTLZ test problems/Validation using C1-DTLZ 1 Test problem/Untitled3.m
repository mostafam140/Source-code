clc
clear all

r_c = [0.3 0.2 0.25 4 0.5 6 7 0.5 9 0.5 11 12 13 14 0.5] ;


obj_num = 3 ;

var_num = obj_num + 10 - 1 ;    % NOTE 10: K should be check for other dtlz

s1 = 12 ;
s2 = 0 ;    % upper level spacing

def.popSize = obj_num ;

[def.popSize,w] = direction_vector(s1, s2, obj_num) ;
w_dense = w ;

for i_w = 1 : size(w_dense,1)
    
    w_dense(i_w,:) = w(i_w,:)./norm(w(i_w,:)) ;    
    
end

F_val = w_dense 

input('line 27')

size(F_val)
                
cons_1 = 0 ;

summ2 = 0 ;

for st = 1 : size(F_val,1)
    
    f_val = F_val(st,:) ; % [A(st)  sqrt(1-A(st)^2)] ;
    
    summ2 = 0 ;
    for i_cons = 1 : obj_num
        summ = 0 ;
                    for j = 1 : obj_num                        
                        if i_cons ~= j
                            summ = summ + (f_val(j)^2) - (r_c(obj_num)^2) ;
                        end
                    end
                    
                    cons_1(st, i_cons) = (f_val(i_cons)-1)^2 + summ  ; % + summ ;  % 1 - f_val(3)/0.6 - ( (f_val(1)/0.5) + (f_val(2)/0.5) ) ;
                    
                    summ2 = summ2 + ((f_val(i_cons) - 1/sqrt(obj_num))^2) - (r_c(obj_num)^2) ;
                    
    end
    cons_1(st,obj_num+1) = summ2 ;
    
    if min(cons_1(st,:)) <= 0
        plot3(f_val(1) , f_val(2), f_val(3),'o','LineWidth',1,...
                                    'MarkerEdgeColor','k',...
                                    'MarkerFaceColor','b',...
                                    'MarkerSize',6) ;
        hold on
        grid on
    else
        plot3(f_val(1) , f_val(2), f_val(3),'o','LineWidth',1,...
                                    'MarkerEdgeColor','k',...
                                    'MarkerFaceColor','r',...
                                    'MarkerSize',6) ;
        hold on
        grid on
    end
end

                
%                 cons_1(:)
%                 summ2
cons_1
% summ2
%                 cons = max([cons_1 summ2]) 
                

function [n,w] = direction_vector(s1,s2,m)
[n,w] = gen_weight(s1,m);
if s2 > 0
    [n2,w2] = gen_weight(s2,m);
    n = n+n2;
    w = [w;w2*0.5+(1 - 0.5)/(m)];
end
return
end

% Generating the direction vectors
function [n,w]=gen_weight(p,M)
NumPoints((1:M-1))=p;
% partitioned into the first objective
Beta1 = (0:(NumPoints(1)))'/(NumPoints(1));
Beta = Beta1;
for i = 2:M-1
    ki = round((1-sum(Beta1,2))*(NumPoints(i)));
    Beta = [];
    for j =1:size(Beta1,1)
        BetaVec = (0:ki(j))'/(NumPoints(i));
        Beta = [Beta; [repmat(Beta1(j,:), length(BetaVec),1) BetaVec] ];
    end
    Beta1 = Beta;
end
w= [Beta (1 - sum(Beta1,2))]; 
n=size(w,1);
return
end

